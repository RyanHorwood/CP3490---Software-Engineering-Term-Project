package com.example.cadeapp;

public interface AsyncResponse {
    public void processFinish(String output);
}

