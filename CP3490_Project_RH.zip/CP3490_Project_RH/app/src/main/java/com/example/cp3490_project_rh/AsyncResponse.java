package com.example.cp3490_project_rh;

public interface AsyncResponse {
    public void processFinish(String output);
}

